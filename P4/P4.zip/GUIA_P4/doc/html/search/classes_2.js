var searchData=
[
  ['iterator',['iterator',['../classGuia__Tlf_1_1iterator.html',1,'Guia_Tlf']]]
];
