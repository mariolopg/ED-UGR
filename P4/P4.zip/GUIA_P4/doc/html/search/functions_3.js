var searchData=
[
  ['insert',['insert',['../classGuia__Tlf.html#add78a6fe5e8090ad6f71bbb160b70f77',1,'Guia_Tlf::insert(string nombre, string tlf)'],['../classGuia__Tlf.html#a4c4e4cc9540896434edd915296e56c87',1,'Guia_Tlf::insert(pair&lt; string, string &gt; p)']]]
];
