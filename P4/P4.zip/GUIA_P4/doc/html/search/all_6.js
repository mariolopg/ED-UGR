var searchData=
[
  ['size',['size',['../classGuia__Tlf.html#a727ab46d490b4196a71f623644906a81',1,'Guia_Tlf']]]
];
