var indexSectionsWithContent =
{
  0: "bcginos",
  1: "cgi",
  2: "bcginos",
  3: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "related"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Funciones",
  3: "Amigas"
};

