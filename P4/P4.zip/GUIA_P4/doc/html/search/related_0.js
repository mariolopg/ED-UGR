var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classGuia__Tlf.html#a73eb02557f3118999710c66aa9ecf309',1,'Guia_Tlf']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classGuia__Tlf.html#ac15a5b0c2eb7d5b1843f11beb492495e',1,'Guia_Tlf']]]
];
