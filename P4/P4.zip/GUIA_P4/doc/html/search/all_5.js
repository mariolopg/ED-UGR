var searchData=
[
  ['operator_2b',['operator+',['../classGuia__Tlf.html#a3e0b08a1985d3c72853690730319172f',1,'Guia_Tlf']]],
  ['operator_2d',['operator-',['../classGuia__Tlf.html#ac381d53f275ce769830e07fbc56902b0',1,'Guia_Tlf']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../classGuia__Tlf.html#a73eb02557f3118999710c66aa9ecf309',1,'Guia_Tlf']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classGuia__Tlf.html#ac15a5b0c2eb7d5b1843f11beb492495e',1,'Guia_Tlf']]],
  ['operator_5b_5d',['operator[]',['../classGuia__Tlf.html#ab2c734a7f3f3cd63ad95f525502474ea',1,'Guia_Tlf']]]
];
