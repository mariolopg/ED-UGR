var searchData=
[
  ['clear',['clear',['../classGuia__Tlf.html#a36ac970ece51a62763bb3898159d0047',1,'Guia_Tlf']]],
  ['const_5fiterator',['const_iterator',['../classGuia__Tlf_1_1const__iterator.html',1,'Guia_Tlf']]],
  ['contabiliza',['contabiliza',['../classGuia__Tlf.html#aa63213524c6339ea89baae2b5d2ebb69',1,'Guia_Tlf']]]
];
