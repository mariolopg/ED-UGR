var searchData=
[
  ['borrar',['borrar',['../classGuia__Tlf.html#a57e32bbc9e76567d22e5275d4d2a6515',1,'Guia_Tlf::borrar(const string &amp;nombre)'],['../classGuia__Tlf.html#af8adac24fd35985b9016a4a38cca60f4',1,'Guia_Tlf::borrar(const string &amp;nombre, const string &amp;tlf)']]],
  ['buscar_5fcontactos_5fpor_5fdebajo_5fnombre',['Buscar_contactos_por_debajo_nombre',['../classGuia__Tlf.html#ab6b614acc6421415f8ac37b473855243',1,'Guia_Tlf']]],
  ['buscar_5fcontactos_5fpor_5fletra',['Buscar_contactos_por_letra',['../classGuia__Tlf.html#af47c1b9b812dc15f138989472e430515',1,'Guia_Tlf']]]
];
