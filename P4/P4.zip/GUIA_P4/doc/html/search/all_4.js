var searchData=
[
  ['numeronombresiguales',['numeroNombresIguales',['../classGuia__Tlf.html#a43c5d8b5c8e1dbb7add384222995cdaf',1,'Guia_Tlf']]]
];
