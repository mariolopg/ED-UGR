var searchData=
[
  ['operator_2b',['operator+',['../classDiccionario.html#a8250d343fd9d712c5a2a130a8d430a7e',1,'Diccionario']]]
];
