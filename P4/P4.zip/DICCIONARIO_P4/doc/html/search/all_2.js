var searchData=
[
  ['getclave',['getClave',['../classDiccionario.html#a1e70807b9a2730e0d23cb7511da4536a',1,'Diccionario']]]
];
